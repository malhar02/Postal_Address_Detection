# google_verifier.py

import googlemaps
from config import GOOGLE_MAPS_API_KEY

def verify_address_with_google(address_string: str) -> dict:
    """
    Uses the Google Maps Geocoding API to verify and geocode an address.

    Args:
        address_string: The raw address string to verify.

    Returns:
        A dictionary containing the verification status, confidence, and formatted address.
    """
    if not GOOGLE_MAPS_API_KEY or GOOGLE_MAPS_API_KEY == "YOUR_API_KEY_HERE":
        return {
            "status": "API_ERROR",
            "error_message": "Google Maps API key is not configured in config.py."
        }

    try:
        gmaps = googlemaps.Client(key=GOOGLE_MAPS_API_KEY)
        geocode_result = gmaps.geocode(address_string)

        if not geocode_result:
            return {
                "status": "NO_MATCH_FOUND",
                "confidence": "None",
                "verified_address": None
            }

        # Check for partial matches or low accuracy
        first_result = geocode_result[0]
        if first_result.get("partial_match", False):
            confidence = "Low (Partial Match)"
        else:
            # ROOFTOP is the most accurate result type
            location_type = first_result['geometry']['location_type']
            if location_type == 'ROOFTOP':
                confidence = "High (Rooftop Accuracy)"
            elif location_type == 'RANGE_INTERPOLATED':
                confidence = "Medium (Street Number Accuracy)"
            else:
                confidence = "Low (Approximate Location)"

        return {
            "status": "MATCH_FOUND",
            "confidence": confidence,
            "verified_address": first_result.get('formatted_address')
        }

    except googlemaps.exceptions.ApiError as e:
        return {"status": "API_ERROR", "error_message": f"Google Maps API Error: {e}"}
    except Exception as e:
        return {"status": "CLIENT_ERROR", "error_message": f"An unexpected error occurred: {e}"}