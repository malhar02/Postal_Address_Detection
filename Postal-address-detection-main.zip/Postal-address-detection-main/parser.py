
from postal.parser import parse_address

def get_parsed_address(address_string: str) -> dict:

    try:
        parsed_components = parse_address(address_string)
        # Convert the list of tuples from libpostal to a more accessible dictionary
        address_dict = {label: value for value, label in parsed_components}
        return address_dict
    except Exception as e:
        print(f"Error during address parsing: {e}")
        return {}