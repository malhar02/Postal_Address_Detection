import React, { useState } from 'react';
import './App.css';

function App() {
  const [address, setAddress] = useState('');
  const [report, setReport] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setReport('');

    try {
      const response = await fetch('http://127.0.0.1:5001/api/process_address', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ address }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      setReport(data.report);
    } catch (error) {
      setReport('An error occurred: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Postal Address Error Detection</h1>
        <p>Enter a postal address below to validate it.</p>
        <form onSubmit={handleSubmit} className="address-form">
          <textarea
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="e.g., 123 Main St, Anytown, CA 90210"
            rows="4"
            required
          />
          <button type="submit" disabled={isLoading}>
            {isLoading ? 'Validating...' : 'Validate Address'}
          </button>
        </form>
        {report && (
          <pre className="report">
            {report}
          </pre>
        )}
      </header>
    </div>
  );
}

export default App;
