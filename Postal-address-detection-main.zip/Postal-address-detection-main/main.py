# main.py

import parser
import validator
# import verifier  <- We'll use the new Google verifier instead
import google_verifier

def generate_final_report(raw_address, validation_errors, suggestions, api_result):
    print("\n" + "="*50)
    print("      Final Address Validation Report")
    print("="*50)
    print(f"Original Input: '{raw_address}'\n")

    # Determine overall status based on Google's API result
    is_valid_format = not validation_errors
    is_verified = api_result.get('status') == 'MATCH_FOUND'

    if is_valid_format and is_verified:
        print("✅ STATUS: VALIDATION SUCCESSFUL")
        print(f"   Confidence Level: {api_result.get('confidence')}")
        print(f"   Verified Address: {api_result.get('verified_address')}")
    else:
        print("❌ STATUS: VALIDATION FAILED")
        if validation_errors:
            print("\n--- Format Errors Detected ---")
            for err in validation_errors:
                print(f"  - {err}")
        if suggestions:
            print("\n--- Suggestions for Typos ---")
            for field, sug in suggestions.items():
                print(f"  - For field '{field}': {sug}")
        
        print("\n--- Google API Verification Check ---")
        if api_result.get('status') == 'NO_MATCH_FOUND':
            print("  - Result: Address could not be found by Google Maps.")
        elif api_result.get('status') == 'MATCH_FOUND':
            print("  - Result: Google found a possible match despite format errors.")
            print(f"  - Confidence Level: {api_result.get('confidence')}")
            print(f"  - Suggested Address: {api_result.get('verified_address')}")
        elif api_result.get('status') in ['API_ERROR', 'CLIENT_ERROR']:
            print(f"  - Error: {api_result.get('error_message')}")

    print("\n" + "="*50)


def process_address(address_string):
    """
    Main workflow to process a single address string using the Google Maps verifier.
    """
    print(f"\nProcessing address: '{address_string}'...")
    parsed_address = parser.get_parsed_address(address_string)
    if not parsed_address:
        print("Could not parse the address. Aborting.")
        return

    # Step 2: Validate the format and get typo suggestions
    validation_errors = validator.validate_address_format(parsed_address)
    correction_suggestions = validator.get_correction_suggestions(parsed_address)

    # Step 3: Use the Google Maps API to verify the raw address
    # Google's API is excellent at handling raw, uncorrected strings.
    api_verification_result = google_verifier.verify_address_with_google(address_string)

    # Step 4: Generate and print the final report
    generate_final_report(address_string, validation_errors, correction_suggestions, api_verification_result)


# This block runs when the script is executed directly
if __name__ == "__main__":
    # --- Test Case 1: An address with multiple errors ---
    address_with_errors = "123 Main Streeet, Anytown, CA 9021"
    process_address(address_with_errors)

    # --- Test Case 2: A real, valid address ---
    valid_address = "1 Infinite Loop, Cupertino, CA 95014" # Apple HQ
    process_address(valid_address)
    
    # --- Test Case 3: A non-existent but well-formatted address ---
    non_existent_address = "999 Fantasy Lane, Fictionville, NV 12345"
    process_address(non_existent_address)