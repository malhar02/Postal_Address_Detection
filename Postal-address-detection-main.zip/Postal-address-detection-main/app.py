
from flask import Flask, request, jsonify
from flask_cors import CORS
from main import process_address
import io
import sys

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/api/process_address', methods=['POST'])
def handle_address():
    data = request.get_json()
    address = data.get('address')

    if not address:
        return jsonify({'error': 'Address not provided'}), 400

    # Redirect stdout to capture the print output from process_address
    old_stdout = sys.stdout
    sys.stdout = captured_output = io.StringIO()

    process_address(address)

    # Restore stdout
    sys.stdout = old_stdout
    output = captured_output.getvalue()

    return jsonify({'report': output})

if __name__ == '__main__':
    app.run(debug=True, port=5001)
