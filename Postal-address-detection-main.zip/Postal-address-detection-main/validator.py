
# validator.py

import re
from fuzzywuzzy import process

def validate_address_format(parsed_address: dict) -> list:
    errors = []
    # Rule 1: Check for the presence of essential components for a US address.
    required_fields = ['house_number', 'road', 'city', 'state', 'postcode']
    for field in required_fields:
        if field not in parsed_address:
            errors.append(f"Missing required field: '{field}'")

    # Rule 2: Validate US ZIP code format using a regular expression.
    if 'postcode' in parsed_address:
        # A standard US ZIP code is 5 digits. This regex enforces that.
        zip_code_pattern = re.compile(r'^\d{6}$')
        if not zip_code_pattern.match(parsed_address['postcode']):
            errors.append(f"Invalid ZIP code format for '{parsed_address['postcode']}'. Expected 5 digits.")

    return errors

def get_correction_suggestions(parsed_address: dict) -> dict:
    suggestions = {}
    # In a real application, this list would come from a database for a specific city/state.
    known_street_names = ["Main Street", "Oak Avenue", "Pine Road", "Elm Street", "Washington Boulevard"]

    if 'road' in parsed_address:
        street_name = parsed_address['road']
        # Find the best match from our list of known street names.
        best_match, score = process.extractOne(street_name, known_street_names)

        # If the match score is high (>80) but not a perfect match (100), it's likely a typo.
        if 80 < score < 100:
            suggestions['road'] = f"Did you mean '{best_match}'?"

    return suggestions