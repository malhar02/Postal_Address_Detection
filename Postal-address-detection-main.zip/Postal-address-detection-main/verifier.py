# verifier.py

import requests

def verify_address_with_api(parsed_address: dict) -> dict:
    
    # Construct the query parameters for the API call.
    query_params = {
        'street': f"{parsed_address.get('house_number', '')} {parsed_address.get('road', '')}",
        'city': parsed_address.get('city', ''),
        'state': parsed_address.get('state', ''),
        'postalcode': parsed_address.get('postcode', ''),
        'country': 'USA', # Be specific to improve results
        'format': 'json',
        'limit': 1
    }

    try:
        # Make the API request with a user-agent, which is good practice.
        headers = {'User-Agent': 'AddressValidator/1.0'}
        response = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params=query_params,
            headers=headers
        )
        response.raise_for_status()  # Raise an HTTPError for bad responses (4xx or 5xx)
        results = response.json()

        if results:
            # The API found at least one match.
            return {
                "status": "MATCH_FOUND",
                "confidence": "High",
                "verified_address": results[0].get('display_name')
            }
        else:
            # The API did not find a match.
            return {
                "status": "NO_MATCH_FOUND",
                "confidence": "Low",
                "verified_address": None
            }

    except requests.exceptions.RequestException as e:
        return {"status": "API_ERROR", "error_message": str(e)}